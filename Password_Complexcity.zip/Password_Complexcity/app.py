from flask import Flask, render_template, request

app = Flask(__name__)

def evaluate_strength(password):
    length = len(password) >= 8
    upper = any(c.isupper() for c in password)
    lower = any(c.islower() for c in password)
    digit = any(c.isdigit() for c in password)
    special = any(c in '!@#$%^&*()_+[]{}|;:,.<>?/~`' for c in password)

    score = sum([length, upper, lower, digit, special])

    if score <= 2:
        return "Weak", "red"
    elif score == 3 or score == 4:
        return "Moderate", "yellow"
    else:
        return "Strong", "lime"

@app.route('/', methods=['GET', 'POST'])
def home():
    strength = None
    color = None

    if request.method == 'POST':
        password = request.form['password']
        strength, color = evaluate_strength(password)

    return render_template('index.html', strength=strength, color=color)

if __name__ == '__main__':
    app.run(debug=True)
